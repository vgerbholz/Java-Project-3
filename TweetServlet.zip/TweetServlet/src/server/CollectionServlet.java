package server;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.HTTP;
import org.json.JSONArray;
import org.json.JSONObject;

import model.Tweet;
import model.TweetCollection;

/**
 * Servlet implementation class CollectionServlet
 */
@WebServlet("/CollectionServlet")
public class CollectionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private final String data_file = "/WEB-INF/data.txt";
	private TweetCollection collection;
	
	/**
	 * Default constructor.
	 */
	public CollectionServlet() {
		
	}

	private JSONObject getRequestJson(HttpServletRequest request) {
		StringBuffer jb = new StringBuffer();
		String line = null;
		try {
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null) {
				jb.append(line);
			}
			reader.close();
		} catch (Exception e) {
			return null;
		}

		try {
			return HTTP.toJSONObject(jb.toString());
		} catch (Exception e) {
			return null;
		}
	}
	private void initCollection() {
		if(collection == null) {
			collection = new TweetCollection(getServletContext().getRealPath(data_file));
			collection.readData();
		}
	}
	private JSONArray getDataCollectionAsJson(String id, String user) {
		try {
			initCollection();
			
			JSONArray array = new JSONArray();
			for(String key : collection.getCollection().keySet()) {
				Tweet tweet = collection.getCollection().get(key);
				if(tweet == null) continue;
				if(id != null && !id.trim().isEmpty()) {
					if(!tweet.getId().equals(id)) continue;
				}
				if(user != null && !user.trim().isEmpty()) {
					if(!tweet.getUser().equals(user)) continue;
				}
				JSONObject tweetJson = new JSONObject(tweet);
				tweetJson.put("update", "0");
				tweetJson.put("delete", "1");
				array.put(tweetJson);
			}
			return array;
		}catch(Exception e){
			return null;
		}
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String method = request.getParameter("functionname");
		if(method != null) {
			// TODO Auto-generated method stub
			if(method.equals("load_all")) {
				response.getWriter().append(getDataCollectionAsJson(null, null).toString());
			} else if(method.equals("search")) {
				String id = request.getParameter("id");
				String user = request.getParameter("user");
				response.getWriter().append(getDataCollectionAsJson(id, user).toString());
				
			} else if(method.equals("update")) {
				
				String id = request.getParameter("id");
				String user = request.getParameter("user");
				String polarity = request.getParameter("polarity");
				String text = request.getParameter("text");
				
				Tweet updated_tweet = new Tweet();
				updated_tweet.setId(id);
				updated_tweet.setUser(user);
				updated_tweet.setPolarity(polarity);
				updated_tweet.setText(text);
				
				if(collection.getCollection().containsKey(id)) {
					collection.getCollection().put(id, updated_tweet);
					collection.writeCollection(getServletContext().getRealPath(data_file));
					JSONObject response_obj = new JSONObject();
					response_obj.put("res", "success");
					
					response.getWriter().append(response_obj.toString());
				} else {
					JSONObject response_obj = new JSONObject();
					response_obj.put("res", "fail");
					
					response.getWriter().append(response_obj.toString());
				}
				
			} else if(method.equals("delete")) {
				
				String id = request.getParameter("id");
			
				collection.getCollection().remove(id);
				collection.writeCollection(getServletContext().getRealPath(data_file));
				
				JSONObject response_obj = new JSONObject();
				response_obj.put("res", "success");
				
				response.getWriter().append(response_obj.toString());
				
			} else if(method.equals("add")) {
				
				String id = request.getParameter("id");
				String user = request.getParameter("user");
				String polarity = request.getParameter("polarity");
				String text = request.getParameter("text");
				
				Tweet new_tweet = new Tweet();
				new_tweet.setId(id);
				new_tweet.setUser(user);
				new_tweet.setPolarity(polarity);
				new_tweet.setText(text);
				
				if(collection.getCollection().containsKey(id)) {
					JSONObject response_obj = new JSONObject();
					response_obj.put("res", "exist");
					
					response.getWriter().append(response_obj.toString());
				}else {
					collection.getCollection().put(id, new_tweet);
					collection.writeCollection(getServletContext().getRealPath(data_file));
					
					JSONObject response_obj = new JSONObject();
					response_obj.put("res", "success");
					
					response.getWriter().append(response_obj.toString());
				}
			} 
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
