package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class TweetCollection {
	private String filename;
	private Map<String, Tweet> collections;
	
	public TweetCollection(String filename) {
		this.filename = filename;
		collections = new LinkedHashMap<String, Tweet>();
	}
	
	public void readData() {
		try {
			collections.clear();
			
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			String line = null;
			while((line = reader.readLine()) != null) {
				String[] splits = line.split(",");
				String polarity = splits[0];
				String id = splits[1];
				String user = splits[2];
				String text = splits[3];
				
				Tweet tweet = new Tweet();
				tweet.setPolarity(polarity);
				tweet.setId(id);
				tweet.setUser(user);
				tweet.setText(text);
				collections.put(id, tweet);
			}
			reader.close();
			System.out.println("Complete to read collections");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public Map<String, Tweet> getCollection(){
		return collections;
	}
	//retrieve tweet by id
	public Tweet getTweetById(String id) {
		return collections.get(id);
	}
	//retrieve all ids of collection
	public Set<String> getAllIds() {
		return collections.keySet();
	}
	//retrieve ids by user
	public List<String> getIdsByUser(String user){
		List<String> id_list = new ArrayList<String>();
		for(String id : getAllIds()) {
			Tweet tweet = getTweetById(id);
			if(tweet == null) continue;
			String username = tweet.getUser();
			if(username.equals(user)) {
				id_list.add(tweet.getId());
			}
		}
		return id_list;
	}
	//delete twitter by id
	public void deleteTweet(String id) {
		collections.remove(id);
	}
	//get collection test result
	public float collectionTest(TweetCollection test_collection) {
		if(getCollection().isEmpty()) return 0;
		
		//start checking
		int correct_num = 0;
		int tested_num = 0;
		for(String id : test_collection.getAllIds()) {
			Tweet test_tweet = test_collection.getTweetById(id);
			String test_polarity = test_tweet.getPolarity();
			
			
			Tweet data_tweet = getTweetById(id);
			if(data_tweet != null) {
				tested_num++;
				String data_polarity = data_tweet.getPolarity();
				if(data_polarity.equals(test_polarity)) {
					correct_num++;
				}
			}
		}
		//get accuracy
		return (float)correct_num / (float)tested_num;
	}
	
	public void writeCollection(String filename) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
			for(String id : getAllIds()) {
				writer.write(getTweetById(id).toString() + System.lineSeparator());
			}
			writer.close();
			System.out.println("Complete backup collections to file");
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
