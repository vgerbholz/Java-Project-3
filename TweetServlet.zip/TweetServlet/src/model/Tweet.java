package model;

public class Tweet {
	private String polarity;
	private String id;
	private String user;
	private String text;
	
	public Tweet() {
		
	}
	
	public void setPolarity(String polarity) {
		this.polarity = polarity;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	public String getPolarity() {
		return polarity;
	}
	public String getId() {
		return id;
	}
	public String getUser() {
		return user;
	}
	public String getText() {
		return text;
	}
	
	@Override
	public String toString() {
		return polarity + "," + id + "," + user + "," + text;
	}
}
